# Edu Bot
This is a educational bot developed by Robo Tech Vally.

- checkout our website for more details https://robotechvally.com

